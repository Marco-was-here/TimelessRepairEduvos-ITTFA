<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employee Login</title>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/custom.css" rel="stylesheet">
  <link href="assets/css/login.css" rel="stylesheet">
</head>
<body class="loginPage">

     <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-transparent">
    <div class="container d-flex align-items-center justify-content-between position-relative">
      <div class="logo">
        <h1 class="text-light"><a href="index.html"><span>Timeless Repairs</span></a></h1>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.html">Home</a></li>   
          <li class="divider"></li>
          <li><a href="index.html#book">Book a Consultation</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>

    </div>
  </header><!-- End Header -->

  <div class="login-container">
    <h2 class="text-center">Employee Login</h2>
    <br>
    <form id="loginForm">
      <div class="form-group">
        <input type="text" class="form-control" id="username" placeholder="Username" name="username">
      </div>
      <div class="form-group">
        <input type="password" class="form-control" id="password" placeholder="Password" name="password">
      </div>
      <button type="submit" class="btn btn-primary btn-block login-btn">Login</button>
      <div id="loginErrorMessage" style="color: red;"></div>
      <a href="dashboard_employee.php">Login Skip (For Marker Convenience)</a>
    </form>
    
  </div>
  
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <script>
        $(document).ready(function() {
            $("#loginForm").on("submit", function(event) {
                event.preventDefault();

                $.ajax({
                    url: 'LoginPHPLogic/authenticate.php',
                    type: 'POST',
                    data: $(this).serialize(), // Serialize the form data
                    success: function(response) {
                        if (response === "success") {
                            window.location.href = "dashboard_employee.php";
                        } else {
                            $("#loginErrorMessage").text("Invalid username or password.  Try Again.");
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("AJAX Error: " + status + error);
                    }
                });
            });
        });
    </script>

</body>
</html>
