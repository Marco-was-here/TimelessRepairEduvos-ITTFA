<?php
// DB connection
$servername = "sql207.infinityfree.com";
$username = "if0_36690923";
$password = "M32UcKC4jREi";
$dbname = "if0_36690923_timeless";

// Create connection (Logging into the database)
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if connected
if(!$conn)
{
    die("Database connection error: " . mysqli_connect_error());
}

$sql = "SELECT * FROM bookings WHERE status = 'pending'";
$result = mysqli_query($conn, $sql);

if($result) {
    while($row = mysqli_fetch_assoc($result))
    {
        echo <<<EOT
            <div class="card">
                <div class="card-header" id="heading{$row['id']}">
                    <h5 class="mb-0">
                        <button class="btn btn" data-toggle="collapse" data-target="#collapse{$row['id']}" aria-expanded="true" aria-controls="collapse{$row['id']}">
                            {$row['created_at']} - <strong>{$row['brand']} - {$row['model']}</strong>
                        </button>
                    </h5>
                </div>

                <div id="collapse{$row['id']}" class="collapse" aria-labelledby="heading{$row['id']}" data-parent="#accordion">
                    <div class="card-body">
                        <p><b>{$row['name']}</b> ({$row['email']} / {$row['cell']}).</p>
                        <p><b>Preferred Date:</b> {$row['requested_time']}</p>
                        <p><strong>Requested Service: </strong> {$row['service']}</p>
                        <p><strong>Issue: </strong> {$row['issue']}</p>
                        <p><strong>Additional Info: </strong> <span class="clientComment">{$row['additional_info']}</span></p>
                        <button type="button" class="btn btn-success btnAcceptBookingRequest" data-booking-id="{$row['id']}">Accept Client</button>
                        <button type="button" class="btn btn-danger btnConfirmBookingDeletion" data-toggle="modal" data-target="#confirmDeleteBookingModal" data-booking-id="{$row['id']}">Delete Request</button>
                    </div>
                </div>
            </div>
        EOT;
    }
} else {
    echo "Error: " . mysqli_error($conn);
}

$conn = null;
?>
