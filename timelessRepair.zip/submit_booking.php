<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Booking Request Sent</title>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/custom.css" rel="stylesheet">
  <link href="assets/css/login.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">


    <style>
        h4 {
            color: white;
        }
    </style>

</head>
<body class="loginPage">

     <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-transparent">
    <div class="container d-flex align-items-center justify-content-between position-relative">
      <div class="logo">
        <h1 class="text-light"><a href="index.html"><span>Timeless Repairs</span></a></h1>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.html">Return Home</a></li>   
          <li class="divider"></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>

    </div>
  </header><!-- End Header -->

  

  <?php
// DB connection
$servername = "sql207.infinityfree.com";
$username = "if0_36690923";
$password = "M32UcKC4jREi";
$dbname = "if0_36690923_timeless";

try {
    // Create a new PDO instance
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get form data
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['cell'];
        $brand = $_POST['brand'];
        $model = $_POST['model'];
        $issue = $_POST['issue'];
        $additional_info = $_POST['additional_info'];
        $requested_date = $_POST['requested_date'];
        $requested_time = $_POST['requested_time'];
        $service = $_POST['service'];

        // Combine date and time
        $combined_datetime = $requested_date . ' ' . $requested_time;

        // Prepare the SQL statement
        $sql = "INSERT INTO bookings (name, email, cell, brand, model, issue, additional_info, requested_time, status, service) 
                VALUES (:name, :email, :phone, :brand, :model, :issue, :additional_info, :requested_time, 'pending', :service)";
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':brand', $brand);
        $stmt->bindParam(':model', $model);
        $stmt->bindParam(':issue', $issue);
        $stmt->bindParam(':additional_info', $additional_info);
        $stmt->bindParam(':requested_time', $combined_datetime);
        $stmt->bindParam(':service', $service);

        // Execute the statement
        $stmt->execute();

        // Display success message
        echo '
        <section id="hero">
            <div class="hero-container" data-aos="fade-up">
                <h1>Booking Request Sent</h1>
                <h4>Hang tight while our expert team reviews your request.</h4>
                <a href="index.html" class="btn-get-started scrollto"><i class="bx bx-home"></i></a>
            </div>
        </section><!-- End Hero -->
        ';
    } else {
        echo "Error: Invalid request.";
    }
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>



 
  
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>




