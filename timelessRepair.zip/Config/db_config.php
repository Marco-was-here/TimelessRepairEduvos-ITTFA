<?php
// DB connection centralised to follow DRY principles.
// Note that this is not used thoughout the entire project.  Some files under BookingPHPLogic, ClientsPHPLogic, EmployeePHPLogic, LoginPHPLogic may need to have this data updated manually.
$servername = "sql207.infinityfree.com";
$username = "if0_36690923";
$password = "M32UcKC4jREi";
$dbname = "if0_36690923_timeless";
?>