<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if (isset($_POST["employee_id"])) {
        $employee_id = $_POST["employee_id"];
       
        $servername = "sql207.infinityfree.com";
        $username = "if0_36690923";
        $password = "M32UcKC4jREi";
        $dbname = "if0_36690923_timeless";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare SQL statement to update user status to "disabled"
        $sql = "UPDATE users SET Status = 'DELETED' WHERE id = ?";
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bind_param("i", $employee_id);

        // Execute statement
        if ($stmt->execute()) {
            echo "User status updated to disabled successfully.";
        } else {
            echo "Error updating user status: " . $conn->error;
        }

        // Close statement and connection
        $stmt->close();
        $conn->close();
    } else {
        // Employee ID not provided
        echo "Error: Employee ID not provided.";
    }
} else {
    // Invalid request method
    echo "Error: Invalid request method.";
}
?>
