<?php

$servername = "sql207.infinityfree.com";
$username = "if0_36690923";
$password = "M32UcKC4jREi";
$dbname = "if0_36690923_timeless";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate input
    $new_password = $_POST["new_password"];
    $employee_id = $_POST["employee_id"];

    // Check if inputs are not empty
    if (empty($new_password) || empty($employee_id)) {
        echo "Error: New password or employee ID is empty.";
        exit; // Exit script if inputs are empty
    }

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement
    $sql = "UPDATE users SET password = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param("si", $new_password, $employee_id);

    // Execute statement
    $stmt->execute();

    // Check if password was updated successfully
    if ($stmt->affected_rows > 0) {
        echo "Password updated successfully.";
    } else {
        echo "Error updating password.";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "Error: Invalid request.";
}
?>
