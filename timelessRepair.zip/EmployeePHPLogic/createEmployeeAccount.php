<?php
    $servername = "sql207.infinityfree.com";
    $username = "if0_36690923";
    $password = "M32UcKC4jREi";
    $dbname = "if0_36690923_timeless";
    
$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Database connection error: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "INSERT INTO users (username, email , password) VALUES ('$username', '$email', '$password')";

    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
