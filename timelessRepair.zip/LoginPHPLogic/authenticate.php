<?php

$servername = "sql207.infinityfree.com";
$username = "if0_36690923";
$password = "M32UcKC4jREi";
$dbname = "if0_36690923_timeless";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
die("Database connection error: " . mysqli_connect_error());
}


// Isset ensures the input is only placed in the $email/$password variables after the form is submitted
if(isset($_POST['password']) && isset($_POST['username']))
{
    // Get email and password from the form in index.php
    $username = $_POST['username'];
    $password = $_POST['password'];


    // Queries the database to check for a user matching the credentials
    $sqlStatement = $conn -> prepare("SELECT * FROM users WHERE username = ? AND password = ?");
    $sqlStatement -> bind_param("ss", $username,$password);
    $sqlStatement -> execute();
    
    $result = $sqlStatement->get_result();
    //Compiles the output into a single variable
    $users = $result->fetch_assoc();

   

    //If a user details are valid
    if($result -> num_rows > 0)
    {
        // Successful Login 
        echo "success";
    }else{
        // Failed Login
        echo "error";
    }

}
else {
    echo "error";
}
?>