<?php
    include 'Config/db_config.php';

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    if(!$conn) {
        die("Database connection error: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM bookings WHERE status = 'accepted'";
    $result = mysqli_query($conn, $sql);

    if($result) {
        while($row = mysqli_fetch_assoc($result)) {
            echo <<<EOT
            <tr>
                <td>{$row['id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['email']}</td>
                <td>{$row['cell']}</td>
                <td>{$row['brand']}</td>
                <td>{$row['model']}</td>
                <td>{$row['service']}</td>
                <td>{$row['issue']}</td>
                <td>{$row['requested_time']}</td>
                <td>
                    <button class="btn btn-link btnCompletedClient" data-toggle="tooltip" data-placement="top" title="Completed" data-booking-id="{$row['id']}">
                        <i class='bx bx-message-rounded-check'></i>
                    </button>
                </td>
            </tr>
            EOT;
        }
        
        
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
?>