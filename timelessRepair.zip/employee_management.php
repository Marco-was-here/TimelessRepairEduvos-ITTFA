<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Dashboard</title>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Timeless Repairs</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <!-- <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon"> -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- CSS Files -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/custom.css" rel="stylesheet">
    <link href="assets/css/login.css" rel="stylesheet">
    <link href="assets/css/employee.css" rel="stylesheet">

    <style>
      .full-width{
        width: 100%;
      }

      .newClients{
        top:40px;
      }

    </style>


</head>
<body class="employeePage">
    <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-transparent">
    <div class="container d-flex align-items-center justify-content-between position-relative">

      <div class="logo">
        <h1 class="text-light"><a href="index.html"><span>Employee Page</span></a></h1>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto" href="dashboard_employee.php">New Consultations</a></li>
          <li><a class="nav-link scrollto" href="clients.php">Clients</a></li>
          <li><a class="nav-link scrollto active" href="employee_management.php">Employeee Management</a></li>
          <li class="divider"></li>
          <li><a href="index.html">Logout</a></li>
        </ul>
    
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <main id="main" class ="full-width">

    <section id="employeeManagement">
      <div class="container">
        <h2 class="mb-4">Employee Management</h2>
        <!-- Employee List -->
        <table class="table table-striped">
          <thead>
            <tr>
              <th>Employee ID</th>
              <th>Username</th>
              <th>Email</th>
              <th>Password</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
              include 'EmployeePHPLogic/getEmployeeData.php';
            ?>
          </tbody>
        </table>
        <button class="btn btn-success" data-toggle="modal" data-target="#createEmployeeModal">Create Employee</button>
      </section>
    </main>




<!-- Create Employee Modal -->
<div class="modal fade" id="createEmployeeModal" tabindex="-1" role="dialog" aria-labelledby="createEmployeeModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createEmployeeModalLabel">Create Employee</h5>
                </div>
                <form id="createEmployeeForm">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="createUsername">Username</label>
                            <input type="text" class="form-control" id="createUsername" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="createEmail">Email</label>
                            <input type="email" class="form-control" id="createEmail" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="createPassword">Password</label>
                            <input type="password" class="form-control" id="createPassword" name="password" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<!-- Change Password Modal -->
<div class="modal fade" id="changePasswordModal" tabindex="-1" role="dialog" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="changePasswordModalLabel">Change Password</h5>
            </div>
            <form id="changePasswordForm">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="newPassword">New Password</label>
                        <input type="password" class="form-control" id="newPassword" name="newPassword" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" id = "updatePassword_btn" class="btn btn-success">Change Password</button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- Delete User Modal -->
<div class="modal fade" id="confirmDeleteModal" tabindex="-1" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="confirmDeleteModalLabel">Confirm Deletion</h5>
      </div>
      <div class="modal-body">
        Are you sure you want to delete this user?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
      </div>
    </div>
  </div>
</div>




  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


  <!-- On the submit of the employee form, this ajax request is made to ensure the user stays on the same page. -->
  <script>
        $(document).ready(function(){
            $("#createEmployeeForm").on("submit", function(event){
                event.preventDefault();

                $.ajax({
                    url: "EmployeePHPLogic/createEmployeeAccount.php",
                    type: "POST",
                    data: $(this).serialize(),
                    success: function(response){
                        $("#createEmployeeModal").modal('hide');
                        //location.reload(); // Reload the page to show the new employee in the table
                    },
                    error: function(xhr, status, error){
                        alert("Error: " + error);
                    }
                });
            });
        });
    </script>


    <script>
        $(document).ready(function(){
          $(".change-password-btn").click(function(){
            var employeeId = $(this).data('employee-id');
            $("#changePasswordForm").attr('data-employee-id', employeeId);
          });

          $("#changePasswordForm").submit(function(e){
            e.preventDefault();
            var employeeId = $(this).data('employee-id');
            var newPassword = $("#newPassword").val();
            
            // AJAX to update password
            $.ajax({
              url: "EmployeePHPLogic/changePassword.php",
              type: "POST",
              data: {
                employee_id: employeeId,
                new_password: newPassword
              },
              success: function(response){
                console.log(response);
                $("#changePasswordForm").modal('hide');
                location.reload();
              },
              error: function(xhr, status, error){
                console.error(xhr.responseText);
              }
            });
          });
        });
    </script>

    <script>
        $(document).ready(function(){
            $(".delete-user-btn").click(function(){
                var employeeId = $(this).data('employee-id');
                $("#confirmDeleteModal").data('employee-id', employeeId); // Set employee ID in the modal
            });

            $("#confirmDeleteBtn").click(function(){
                var employeeId = $("#confirmDeleteModal").data('employee-id');
                
                // AJAX to delete user
                $.ajax({
                    url: "EmployeePHPLogic/deleteUser.php",
                    type: "POST",
                    data: {
                        employee_id: employeeId
                    },
                    success: function(response){
                        console.log(response);
                        $("#confirmDeleteModal").modal('hide');
                        location.reload();
                    },
                    error: function(xhr, status, error){
                        console.error(xhr.responseText);
                    }
                });
            });
        });
    </script>


</body>
</html>