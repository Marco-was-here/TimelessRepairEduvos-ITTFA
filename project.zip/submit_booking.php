<?php
// Step 1: Establish a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "timeless";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    die(); // Terminate script execution
}

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$brand = $_POST['brand'];
$model = $_POST['model'];
$issue = $_POST['issue'];
$additional_info = $_POST['additional_info'];
$scheduled_date = $_POST['scheduled_date'];
$scheduled_time = $_POST['scheduled_time'];
$service = $_POST['service'];

// DB Query
try {
    $stmt = $conn->prepare("INSERT INTO bookings (name, email, cell, brand, model, issue, additional_info, scheduled_date, scheduled_time, service) 
                            VALUES (:name, :email, :phone, :brand, :model, :issue, :additional_info, :scheduled_date, :scheduled_time, :service)");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':brand', $brand);
    $stmt->bindParam(':model', $model);
    $stmt->bindParam(':issue', $issue);
    $stmt->bindParam(':additional_info', $additional_info);
    $stmt->bindParam(':scheduled_date', $scheduled_date);
    $stmt->bindParam(':scheduled_time', $scheduled_time);
    $stmt->bindParam(':service', $service);
    $stmt->execute();
    echo "New record created successfully";
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;
?>
